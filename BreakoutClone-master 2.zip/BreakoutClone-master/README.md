# BreakoutClone
This is a simple breakout game that serves as a companion to my video on my Youtube Channel (BR Studio)

<b>My Youtube channel(BR Studio):</b> https://www.youtube.com/channel/UClmRwdRb2PC6D3gJM-fpYUw

<b>Video Link:</b>https://youtu.be/B_XBzBc63DA

## Image (A picture is worth a thousand words)
<img width="324" alt="screen shot 2016-10-14 at 8 30 36 pm" src="https://cloud.githubusercontent.com/assets/19306879/19387487/19a71fb2-924d-11e6-986a-937521e87282.png">

##Conclusion
If you really want how to make this game step-by step,head in to my Youtube channel and watch the 'Breakout' video today!
